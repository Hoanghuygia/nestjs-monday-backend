export { mock as createMock, MockProxy as Mock } from 'vitest-mock-extended';
