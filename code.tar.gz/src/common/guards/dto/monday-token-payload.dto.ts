interface MondayTokenPayload {
    accountId: number;
    userId: number;
    backToUrl?: string;
    shortLivedToken?: string;
}