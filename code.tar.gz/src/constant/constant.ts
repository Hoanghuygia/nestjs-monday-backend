export const ACCESS_TOKEN_PREFIX = 'monday_access_token_';
export const OAUTH_MONDAY_URL = 'https://auth.monday.com/oauth2/authorize';
export const TOKEN_MONDAY_URL = 'https://auth.monday.com/oauth2/token';